
public class random {

}
